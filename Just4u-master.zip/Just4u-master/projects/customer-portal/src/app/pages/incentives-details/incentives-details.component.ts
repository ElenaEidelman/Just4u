import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-incentives-details',
  templateUrl: './incentives-details.component.html',
  styleUrls: ['./incentives-details.component.scss']
})
export class IncentivesDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
