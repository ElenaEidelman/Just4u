import { EncodeSpacesPipe } from './encode-spaces.pipe';

describe('EncodeSpacesPipe', () => {
  it('create an instance', () => {
    const pipe = new EncodeSpacesPipe();
    expect(pipe).toBeTruthy();
  });
});
