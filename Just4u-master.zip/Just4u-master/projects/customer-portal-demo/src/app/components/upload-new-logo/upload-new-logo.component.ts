import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload-new-logo',
  templateUrl: './upload-new-logo.component.html',
  styleUrls: ['./upload-new-logo.component.scss']
})
export class UploadNewLogoComponent implements OnInit {
  display = false;
  constructor() { }

  ngOnInit(): void {
  }

}
