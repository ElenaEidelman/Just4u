import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-activity-create-setting',
  templateUrl: './activity-create-setting.component.html',
  styleUrls: ['./activity-create-setting.component.scss']
})
export class ActivityCreateSettingComponent implements OnInit {
  name;
  constructor() { }

  ngOnInit(): void {
  }

}
